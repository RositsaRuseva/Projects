﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PhoneBookWApp.Models
{
    public static class DataContext
    {
        public static List<Contact> Contacts { get; set; }


    }
}
