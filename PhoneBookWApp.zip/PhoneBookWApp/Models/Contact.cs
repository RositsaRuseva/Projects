﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PhoneBookWApp.Models
{
    public class Contact
    {
        [Required(ErrorMessage = "The field {0} is required!")]
        [Display(Name = "Name")]
        public string Name { get; set; }

        [Required(ErrorMessage = "The field {0} is required!")]
        [Display(Name = "Number")]
        [StringLength(15, MinimumLength = 5, ErrorMessage = "The field {0} length must be between {2} and {1}")]
        public string Number { get; set; }
    }
}
